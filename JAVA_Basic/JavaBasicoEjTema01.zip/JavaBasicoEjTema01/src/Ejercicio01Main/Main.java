package Ejercicio01Main;

public class Main {
    public static void main(String[] args) {
        int edad;
        String nombre;
        Long talla;
        int peso;
        double altura;
        String sexo;
        boolean inicial;
        float cost;

        edad = 20;
        nombre = "Juan";
        talla = 100L;
        peso = 100;
        altura = 1.80;
        sexo = "M";
        inicial = true;
        cost = 1000;

        System.out.println(edad+" "+nombre+" "+talla+" "+peso+" "+
                altura+" "+sexo+" "+ inicial +" "+cost);
    }
}